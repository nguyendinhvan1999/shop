﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class ProductInfor_DTO
    {
        public int ProductID { get; set; }
        public int RAM { get; set; }
        public int ROM { get; set; }
        public string OperatingSystem { get; set; }
        public int pin { get; set; }
        public string ProductName { get; set; }
        public ProductInfor_DTO()
        { 

        }
        public ProductInfor_DTO(int ProductID, int RAM, int ROM, string OperatingSystem, int pin, string ProductName)
        {
            this.ProductID = ProductID;
            this.RAM = RAM;
            this.ROM = ROM;
            this.OperatingSystem = OperatingSystem;
            this.pin = pin;
            this.ProductName = ProductName;
        }
    }
}
