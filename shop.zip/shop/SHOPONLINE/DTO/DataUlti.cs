﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;

namespace DTO
{
    public class DataUlti
    {
        SqlConnection con;
        public DataUlti()
        {
            string sqlCon = @"Data Source=ADMIN\SQLEXPRESS;Initial Catalog=shoponline234;Integrated Security=True";
            con = new SqlConnection(sqlCon);
        }

        public List<ProductInfor_DTO> dsProductInfor()
        { 
            List<ProductInfor_DTO> ds = new List<ProductInfor_DTO>();
            string sql = "select * from ProductInfor inner join Product on ProductInfor.ProductID=Product.ProductID";
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader rd = cmd.ExecuteReader();
            while(rd.Read())
            {
                ProductInfor_DTO p = new ProductInfor_DTO();
                p.ProductID = (int)rd["ProductID"];
                p.ProductName = (string)rd["ProductName"];
                p.RAM = (int)rd["RAM"];
                p.ROM = (int)rd["ROM"];
                p.OperatingSystem = (string)rd["OperatingSystem"];
                p.pin = (int)rd["pin"];
                ds.Add(p);
            }
            con.Close();
            return ds;               
        }

        public List<Product_DTO> dsProductNotInfor()
        {
            List<Product_DTO> ds = new List<Product_DTO>();
            string sql = "select * from Product where not exists (select * from ProductInfor where Product.ProductID = ProductInfor.ProductID)"; ;
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader rd = cmd.ExecuteReader();
            while(rd.Read())
            {
                Product_DTO pro= new Product_DTO();
                pro.ProductID_ = (int)rd["ProductID"];
                
                pro.ProductName_ = (string)rd["ProductName"];
                pro.Description_ = (string)rd["Description"];
                pro.Photo_ = (string)rd["Photo"];
                pro.Quantity_ = (int)rd["Quantity"];
                pro.Cost_ = (decimal)rd["Cost"];
                ds.Add(pro);
            }
            con.Close();
            return ds;
        }

        public void InsertProductInfor(ProductInfor_DTO p)
        {
            con.Open();
            string sql = "insert into ProductInfor values(@ProductID,@RAM,@ROM,@OperatingSystem,@pin)";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("ProductID", p.ProductID);
            cmd.Parameters.AddWithValue("RAM", p.RAM);
            cmd.Parameters.AddWithValue("ROM", p.ROM);
            cmd.Parameters.AddWithValue("OperatingSystem", p.OperatingSystem);
            cmd.Parameters.AddWithValue("pin", p.pin);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void DeleteProductInfor(int ProductID)
        {
            con.Open();
            string sql = "delete from ProductInfor where ProductID=@ProductID";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("ProductID", ProductID);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void UpdateProductInfor(ProductInfor_DTO p)
        {
            
            string sql = "update ProductInfor set RAM=@RAM, ROM=@ROM, OperatingSystem=@OperatingSystem, pin=@pin where ProductID=@ProductID";
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("ProductID", p.ProductID);
            cmd.Parameters.AddWithValue("RAM", p.RAM);
            cmd.Parameters.AddWithValue("ROM", p.ROM);
            cmd.Parameters.AddWithValue("OperatingSystem", p.OperatingSystem);
            cmd.Parameters.AddWithValue("pin", p.pin);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public ProductInfor_DTO laythongtin(int ProductID)
        {
            List<ProductInfor_DTO> ds = new List<ProductInfor_DTO>();
            string sql = "select * from ProductInfor where ProductID=@ProductID";
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("ProductID", ProductID);
            ProductInfor_DTO p = null;
            SqlDataReader rd=cmd.ExecuteReader();
            while(rd.Read())
            {
                p = new ProductInfor_DTO();
                p.ProductID = (int)rd["ProductID"];
                p.RAM = (int)rd["RAM"];
                p.ROM = (int)rd["ROM"];
                p.OperatingSystem = (string)rd["OperatingSystem"];
                p.pin = (int)rd["pin"];
            }
            con.Close();
            return p;
        }

        public List<Product_DTO> dsProducts()
        {
            List<Product_DTO> ds = new List<Product_DTO>();
            string sql = "select * from Product";
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                Product_DTO pro = new Product_DTO();
                pro.ProductID_ = (int)rd["ProductID"];

                pro.ProductName_ = (string)rd["ProductName"];
                pro.Description_ = (string)rd["Description"];
                pro.Photo_ = (string)rd["Photo"];
                pro.Quantity_ = (int)rd["Quantity"];
                pro.Cost_ = (decimal)rd["Cost"];
                ds.Add(pro);
            }
            con.Close();
            return ds;
        }
    }
}
