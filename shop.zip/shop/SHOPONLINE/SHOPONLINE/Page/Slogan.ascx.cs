﻿using System;

namespace SHOPONLINE.Page
{
    public partial class slogan : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}