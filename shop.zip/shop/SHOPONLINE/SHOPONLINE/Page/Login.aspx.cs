﻿using BUS;
using System;
using System.Data;


namespace SHOPONLINE.Page
{
    public partial class Login : System.Web.UI.Page
    {
        Login_BUS bus = new Login_BUS();
        public static string username;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDangNhap_Click(object sender, EventArgs e)
        {
            username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            DataTable dt = new DataTable();
            dt = bus.CheckLogin(username, password);
            if (dt.Rows.Count > 0  )
            {
                if (dt.Rows[0]["UserName"].ToString() != "admin")
                {
                    Session["login"] = username;
                    Response.Redirect("Home.aspx");
                }
                else
                {
                    Response.Redirect("~/Page/Admin/Login.aspx");
                }
            }
            else
            {
                Response.Write("<script>alert('Tên đăng nhập hoặc mật khẩu không chính xác!')</script>");
            }
        }
    }
}