﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BUS;
using System.Data;

namespace SHOPONLINE.Page
{
    public partial class donmua : System.Web.UI.Page
    {
        Order_BUS bus = new Order_BUS();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ShowOrder();
            }
        }
        public void ShowOrder()
        {
            DataTable dt = new DataTable();
            dt = bus.ShowOrders();
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }
        protected void btnDetail_Click(object sender, EventArgs e)
        {
            Button btnDetail = sender as Button;
            GridViewRow grvr = btnDetail.NamingContainer as GridViewRow;
            string orderid = GridView1.DataKeys[grvr.RowIndex].Value.ToString();
            Response.Redirect("~/Page/donmua1.aspx?orderid=" + orderid);
        }
    }
}