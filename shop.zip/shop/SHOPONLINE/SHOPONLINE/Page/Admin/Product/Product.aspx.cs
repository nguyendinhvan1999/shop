﻿using BUS;
using System;
using System.Data;
using System.Web.UI.WebControls;
namespace SHOPONLINE.Page.Admin.product
{
    public partial class product : System.Web.UI.Page
    {
        Product_BUS bus = new Product_BUS();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ShowProduct();
            }

            string alert = Request.QueryString["alert"];
            if (alert != null)
            {
                Response.Write("<script>alert('" + alert + "')</script>");
            }
        }

        public void ShowProduct()
        {
            GridView1.DataSource = bus.ShowProduct();
            GridView1.DataBind();
        }

        protected void btnThemSP_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Page/Admin/Product/InsertProduct.aspx");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            Button btnXoa = sender as Button;
            GridViewRow grvr = btnXoa.NamingContainer as GridViewRow;
            int proid = int.Parse(GridView1.DataKeys[grvr.RowIndex].Value.ToString());
            bus.DeleteProduct(proid);
            string alert = "Xóa thành công";
            Response.Redirect("~/Page/Admin/Product/Product.aspx?alert=" + alert);
        }

        protected void btnSua_Click(object sender, EventArgs e)
        {
            Button btnUpdate = sender as Button;
            GridViewRow grvr = btnUpdate.NamingContainer as GridViewRow;
            string id = GridView1.DataKeys[grvr.RowIndex].Value.ToString();
            Response.Redirect("~/Page/Admin/Product/UpdateProduct.aspx?id=" + id);
        }



        protected void LinkButtonSearch_Click(object sender, EventArgs e)
        {
            string productname = txttensp.Text;
            DataTable dt = new DataTable();
            dt = bus.SearchProduct(productname);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            ShowProduct();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}