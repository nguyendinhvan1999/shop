﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BUS;

namespace SHOPONLINE.Page.Admin.Product
{
    public partial class test : System.Web.UI.Page
    {
        Product_BUS bus = new Product_BUS();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnInsert_Click(object sender, EventArgs e)
        {


            string op = txtop.Text;
            int ram = int.Parse(txtram.Text);
            int rom = int.Parse(txtrom.Text);
            int pin = int.Parse(txtpin.Text);
            bus.ShopTop10Product(ram, rom, op, pin);
            string alert = "Thêm thành công";
            Response.Redirect("~/Page/Admin/Product/Product.aspx?alert=" + alert);
            
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {

        }
    }
}