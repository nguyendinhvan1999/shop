﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DTO;

namespace SHOPONLINE.Page.Admin.ProductInfor
{
    public partial class ProductInfor : System.Web.UI.Page
    {
        DataUlti data = new DataUlti();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                hienthi();
        }
        private void hienthi()
        {
            grdDs.DataSource = data.dsProductInfor();
            DataBind();
        }
        protected void xoa_click(object sender,CommandEventArgs e)
        {
            if(e.CommandName=="xoa")
            {
                int m = Convert.ToInt32(e.CommandArgument);
                data.DeleteProductInfor(m);
                hienthi();
            }
        }
        protected void sua_click(object sender, CommandEventArgs e)
        {
            if (e.CommandName == "sua")
            {
                int m = Convert.ToInt32(e.CommandArgument);
                ProductInfor_DTO p = data.laythongtin(m);
                Session["pr"] = p;
                Response.Redirect("UpdateProductInfor.aspx");
                hienthi();
            }
        }

        protected void grdDs_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}