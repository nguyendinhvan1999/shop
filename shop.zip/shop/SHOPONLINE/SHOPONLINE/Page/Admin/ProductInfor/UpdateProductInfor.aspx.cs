﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DTO;

namespace SHOPONLINE.Page.Admin.ProductInfor
{
    public partial class UpdateProductInfor : System.Web.UI.Page
    {
        DataUlti data = new DataUlti();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                ProductInfor_DTO p = (ProductInfor_DTO)Session["pr"];
                ddlid.DataSource = data.dsProducts();
                ddlid.DataTextField = "ProductName_";
                ddlid.DataValueField = "ProductID_";
                ddlid.SelectedValue = p.ProductID.ToString();
                txtRAM.Text = p.RAM.ToString();
                txtROM.Text = p.ROM.ToString();
                txtOS.Text = p.OperatingSystem;
                txtpin.Text = p.pin.ToString();
                DataBind();
            }
        }
        protected void btnSua_Click(object sender,EventArgs e)
        {
            try
            {
                ProductInfor_DTO p = new ProductInfor_DTO();
                p.ProductID = int.Parse(ddlid.SelectedValue);
                p.RAM=int.Parse(txtRAM.Text);
                p.ROM = int.Parse(txtROM.Text);
                p.OperatingSystem = txtOS.Text;
                p.pin = int.Parse(txtpin.Text);
                data.UpdateProductInfor(p);
                msg.Text = "Cập nhật thành công";
            }
            catch(Exception ex)
            {
                msg.Text = "Có lỗi xảy ra: " + ex;
            }
        }
    }
}