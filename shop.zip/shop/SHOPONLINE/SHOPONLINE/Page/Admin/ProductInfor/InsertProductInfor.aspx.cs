﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DTO;
namespace SHOPONLINE.Page.Admin.ProductInfor
{
    public partial class InsertProductInfor : System.Web.UI.Page
    {
        DataUlti data = new DataUlti();
        protected void Page_Load(object sender, EventArgs e)
        {
          if(!IsPostBack)
            {
                ddlid.DataSource = data.dsProductNotInfor();
                ddlid.DataTextField = "ProductName_";
                ddlid.DataValueField = "ProductID_";
                DataBind();
            }
        }
        protected void btnThem_Click(object sender,EventArgs e)
        {
            try
            {
                ProductInfor_DTO p = new ProductInfor_DTO();
                p.ProductID = int.Parse(ddlid.SelectedValue);
                p.RAM = int.Parse(txtRAM.Text);
                p.ROM = int.Parse(txtROM.Text);
                p.OperatingSystem = txtOS.Text;
                p.pin = int.Parse(txtpin.Text);
                data.InsertProductInfor(p);
                msg.Text = "Thêm thông tin thành công";
            }
            catch(Exception ex)
            {
                msg.Text = "Có lỗi xảy ra " + ex.Message;
            }
        }
    }
}