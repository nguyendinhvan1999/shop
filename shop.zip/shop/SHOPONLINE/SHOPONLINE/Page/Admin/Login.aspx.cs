﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BUS;

namespace SHOPONLINE.Page.Admin
{
    public partial class Login1 : System.Web.UI.Page
    {
        Login_BUS bus = new Login_BUS();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DangNhap_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            string role = RadioButtonList1.SelectedValue;

            DataTable dt = new DataTable();
            dt = bus.CheckLoginAdmin(username, password, role);
            if (dt.Rows.Count > 0 && role != "user")
            {
                Session["admin"] = username;
                Response.Redirect("~/Page/Admin/index.aspx");
            }else if (dt.Rows.Count > 0)
            {
                Session["login"] = username;
                Response.Redirect("~/Page/Home.aspx");
            }
            else
            {
                Response.Write("<script>alert('Tên đăng nhập hoặc mật khẩu không chính xác!')</script>");
            }
        }
    }
}