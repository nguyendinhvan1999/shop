﻿using BUS;
using System;
using System.Data;
namespace SHOPONLINE.Page
{
    public partial class Home1 : System.Web.UI.Page
    {
        Home_BUS bus = new Home_BUS();
        AllPhoneAndLaptop_BUS test = new AllPhoneAndLaptop_BUS();
        protected void Page_Load(object sender, EventArgs e)
        {
            string eventTarget = "";
            if (IsPostBack)
            {
                eventTarget = Request.Params["__EVENTTARGET"];
            }
            if (eventTarget.IndexOf("btnIphone") != -1)
            {
                DataTable dt = new DataTable();
                dt = test.All_IPhone();
                DataList1.DataSource = dt;
                DataList1.DataBind();
            }
            else if (eventTarget.IndexOf("btnSamsung") != -1)
            {
                DataTable dt = new DataTable();
                dt = test.All_Samsung();
                DataList1.DataSource = dt;
                DataList1.DataBind();
            }
            else if (eventTarget.IndexOf("btnXiaomi") != -1)
            {
                DataTable dt = new DataTable();
                dt = test.All_Xioma();
                DataList1.DataSource = dt;
                DataList1.DataBind();
            }
            else if (eventTarget.IndexOf("btnIpadmini") != -1)
            {
                DataTable dt = new DataTable();
                dt = test.All_Mini();
                DataList2.DataSource = dt;
                DataList2.DataBind();
            }
            else if (eventTarget.IndexOf("btnIpadAir") != -1)
            {
                DataTable dt = new DataTable();
                dt = test.All_Air();
                DataList2.DataSource = dt;
                DataList2.DataBind();
            }
            else
            {
                Top5Phone();
                Top5Laptop();
                Top5Prouduct();
                Top5News();
            }
        }

        public void Top5Phone()
        {
            DataTable dt = new DataTable();
            dt = bus.ShowTop5Phone();
            DataList1.DataSource = dt;
            DataList1.DataBind();
        }

        public void Top5Laptop()
        {
            DataTable dt = new DataTable();
            dt = bus.ShowTop5Laptop();
            DataList2.DataSource = dt;
            DataList2.DataBind();
        }

        public void Top5Prouduct()
        {
            //DataTable dt = new DataTable();
            //dt = bus.ShopTop5Product();
            //DataList3.DataSource = dt;
            //DataList3.DataBind();
        }

        public void Top5News()
        {
            DataTable dt = new DataTable();
            dt = bus.ShowTopNews();
            DataList4.DataSource = dt;
            DataList4.DataBind();
        }

        protected void DataList2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}