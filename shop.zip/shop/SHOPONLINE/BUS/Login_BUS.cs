﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
namespace BUS
{
    public class Login_BUS
    {
        Lop_DAL dal = new Lop_DAL();
        public DataTable CheckLogin(string username, string password)
        {
            string sql = "SELECT * FROM Users WHERE UserName=N'" + username + "' AND Password='" + password + "'";
            DataTable dt = new DataTable();
            dt = dal.GetTable(sql);
            return dt;
        }

        //dang nhap phai admin
        public DataTable CheckLoginAdmin(string username, string password, string role)
        {
            string sql = "SELECT * FROM Users WHERE UserName=N'" + username + "' AND Password='" + password + "' AND Role='" + role + "'";
            DataTable dt = new DataTable();
            dt = dal.GetTable(sql);
            return dt;
        }
    }
}

